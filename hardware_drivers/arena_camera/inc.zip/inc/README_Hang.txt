sudo cp -f \
    /opt/ros/noetic/include/sensor_msgs/image_encodings.h \
    /opt/ros/noetic/include/sensor_msgs/image_encodings.h.bak
    
sudo cp -f \
    ./image_encodings.h \
    /opt/ros/noetic/include/sensor_msgs/image_encodings.h
